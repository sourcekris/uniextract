UFA Archiver 0.04 Beta 1 
------------------------

UFA is a file archiver for Windows 95/98/NT.

UFA Archiver is a freeware product. It may be freely distributed.

Features: 
    High compression ratio.
    Long File Name supporting.
    Solid mode supporting.
    Multimedia compression.

     
This distrubutive packet contains following files:

  readme.txt    - This file
  UfaDoc.txt    - User's Manual in plain text form
  ufa.exe       - UFA Archiver 
  file_id.diz   - Short Description file
  History.txt   - History of UFA Archiver
 

INTERNET
--------

WWW:    http://www.7-zip.com
FTP:    ftp://ftp.elf.stuba.sk/pub/pc/pack/ufa*.zip
E-mail: support@7-zip.com



OTHER PRODUCTS
--------------

    7-ZIP Archiver:   ZIP format compatibility.
                      Highest compression ratio in ZIP format.
                      Console 32 bit version for Windows 95/98/NT.
                      FAR Support.

    Document Press:   Compressing MS Office documents and other
                      compound files. After compression, files 
                      can be used without any decompression.


---
  Igor Pavlov, the author of the UFA Archiver.


End of document
