DEEPF106.EXE [Easy to use, fast and excellent-rate Archiver] DeepFree1.06
============================================================================
[The Soft Name]     DeepFreezer v1.06
[Registered Name]   DEEPF106.EXE
[Copyright]         YAMAZAKI@BinaryTechnology <MHB01175@nifty.ne.jp>
[Operating systems] Windows95, Windows98, WindowsNT4.0, Windows2000
[Comfirmation]      Compatibled with PC-AT
[Extracting]        This is Self-Extracting-Archive
[Category]          Free Software
[Reproducing]       OK. But It is indispensable to inform your reproduce of me.
============================================================================

[Presentation]

           Easy to use, fast and excellent-rate Archiver

               DeepFreezer for Windows95/98/NT/2000

                  Version 1.06 (Sep 19 2000)


***** -Description- *****

-Mainly , text-format-file is best rate of compression. 
 This is realized for developing own-particular-algorithm.
 And also better to compress many log-files,Word-files,Excel-files 
 and Access-files and et cetera.

-The speed is all swift.

-Equipped GUI(You can use this GUI with ease).

-You only drag-and-drop FOLDER , 
 then the files in the folder are all compressed.
 This is very useful.

-This is able to use PASSWARD. Thus Security got to be strong.

-It is also convenient to be able to generate SelF-eXtracting-archive.

-This program is able to extract LZH-files by using UNLHA32.DLL

-This program is able to extract ZIP-files by using UNZIP32.DLL

-This program is able to extract RAR-files by using UNRAR32.DLL , UNRAR.DLL

-This program is able to extract CAB-files by using CAB32.DLL



***** -Support and Service- *****

  E-Mail : MHB01175@nifty.ne.jp (Japanese Only)
           thocd@i.am (English and Japanese Only)
  URL    : http://member.nifty.ne.jp/yamazaki/



=============================================================
End of File
