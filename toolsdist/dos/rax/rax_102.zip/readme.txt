
    R o m a n i a n  A r c h i v e r  e X p e r t (c) 1997, GeCAD 
    -------------------------------------------------------------

    Version 1.x SHAREWARE
    ---------------------



  1. The purpose of the program.

  RAX is a compression toolkit. It is able to compress by adding/moving
  the requested files or folders into an archive. The Shareware version 
  of RAX does not include all the features included in the registred 
  version, but is fully capable of compressing/decompressing programs 
  just like the registred version does.

  2. How to install the program.

  Just run the auto - extractive SFX into a directory on your HDD,
  and run RAX.EXE to start the program. No installation is required at all.

  3. The status of the program (Public Domain, Freeware, or Shareware).

  This program is time-limited Shareware. Please read the LICENSE.TXT file
  for more informations about the license. Please note that you can
  only use this program for 30 days. After that, you should either remove
  the files from your computer, or register.

  4. The distribution status of the program.
  
  You can freely distribute the program. However, no modifications to the
  original distribution archive are allowed. The new versions are
  avaible from http://www.gecad.ro/
  Other faster mirrors are also avaible: check out http://www2.gecad.ro/

  5. How to contact the author in the event of questions or problems.

  Mail any further questions to info@gecad.ro


  RAX1 (Romanian Archiver eXpert) is (c) 1997, GeCAD s.r.l.