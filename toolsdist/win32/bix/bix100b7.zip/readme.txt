BIX Archiver 1.00 Beta 7
------------------------

BIX is a file archiver for Windows 95/NT. 
BIX Archiver is an experimental version of the UFA Archiver.
BIX Archiver is a freeware product. It may be freely distributed.

Features: 
    High compression ratio.
    Fast compression and decompression.
    Incremental Update.
    FAR Support.


  This distrubutive packet contains following files:

  readme.txt    - This file
  BixDoc.htm    - User's Manual in html form
  BixDoc.txt    - User's Manual in plain text form
  bixsort.txt   - File order list for solid archiving
  BixToFar.ini  - File for FAR Manager supporting
  bix.exe       - BIX Archiver 
  file_id.diz   - Short Description file
  History.txt   - History of BIX Archiver


INTERNET
--------

WWW:    http://www.7-zip.com
FTP:    ftp://ftp.elf.stuba.sk/pub/pc/pack/bix*.zip
E-mail: support@7-zip.com



OTHER PRODUCTS
--------------

    7-ZIP Archiver:   ZIP format compatibility.
                      Highest compression ratio in ZIP format.
                      Console 32 bit version for Windows 95/98/NT.
                      FAR Support.

    Document Press:   Compressing MS Office documents and other
                      compound files. After compression, files 
                      can be used without any decompression.



---
  Igor Pavlov, the author of BIX Archiver.


End of document
