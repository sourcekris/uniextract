777 Archiver 0.04 Beta 1 
------------------------

777 is a file archiver for Windows 95/98/NT.
777 is an experimental version of UFA archiver.

777 Archiver is a freeware product. It may be freely distributed.

Features: 
    High compression ratio.
    Long File Name supporting.
    Solid mode supporting.
    Multimedia compression.



  This distrubutive packet contains following files:

  readme.txt    - This file
  777Doc.txt    - User's Manual in plain text form
  777.exe       - 777 Archiver 
  file_id.diz   - Short Description file
  History.txt   - History of 777 Archiver
 


INTERNET
--------

WWW:    http://www.7-zip.com
FTP:    ftp://ftp.elf.stuba.sk/pub/pc/pack/777*.zip
E-mail: support@7-zip.com



OTHER PRODUCTS
--------------

    7-ZIP Archiver:   ZIP format compatibility.
                      Highest compression ratio in ZIP format.
                      Console 32 bit version for Windows 95/98/NT.
                      FAR Support.

    Document Press:   Compressing MS Office documents and other
                      compound files. After compression, files 
                      can be used without any decompression.



---
  Igor Pavlov, the author of the 777 Archiver.


End of document
